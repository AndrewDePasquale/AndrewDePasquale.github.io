const mongoose = require('mongoose');
const Trip = require('../models/travlr'); // Register model
const Model = mongoose.model('trips');

// Get: /trips - list all the trips
// Regardless of outcome, response must include HTML status code
// and JSON message to the requesting client
const tripsList = async(req, res) => {
    try {
        const filter = {};

        // Add supported search criteria to the MongoDB query
        if (req.query.resort) {
            filter.resort = req.query.resort.trim();
        }

        if (req.query.name) {
            filter.name = req.query.name.trim();
        }

        if (req.query.code) {
            filter.code = req.query.code.trim().toUpperCase();
        }

        const q = await Model
            .find(filter)
            .exec();

        if (q.length === 0) {
            return res
                .status(404)
                .json({ message: 'No matching trips found' });
        }

        return res
            .status(200)
            .json(q);

    } catch (err) {
        console.error('Error retrieving trips:', err);

        return res
            .status(500)
            .json({ message: 'Unable to retrieve trips' });
    }
};

// GET: /trips/:tripCode - lists a single trip
// Regardless of outcome, response must include HTTP status code
// and JSON message to the requesting client
const tripsFindByCode = async(req, res) => {
    try {
        const tripCode = req.params.tripCode.trim().toUpperCase();

        const q = await Model
            .findOne({ code: tripCode })
            .exec();

        if (!q) {
            return res
                .status(404)
                .json({ message: 'Trip not found' });
        }

        return res
            .status(200)
            .json(q);

    } catch (err) {
        console.error('Error retrieving trip:', err);

        return res
            .status(500)
            .json({ message: 'Unable to retrieve trip' });
    }
};

// POST: /trips - Adds a new Trip
// Regardless of outcome, response must include HTTP status code
// and JSON message to the requesting client
const tripsAddTrip = async(req, res) => {
    try {
        const newTrip = new Trip({
            code: req.body.code,
            name: req.body.name,
            length: req.body.length,
            start: req.body.start,
            resort: req.body.resort,
            perPerson: req.body.perPerson,
            image: req.body.image,
            description: req.body.description
        });

        const q = await newTrip.save();

        return res
            .status(201)
            .json(q);

    } catch (err) {
        console.error('Error adding trip:', err);

        if (err.name === 'ValidationError') {
            return res
                .status(400)
                .json({ message: 'Invalid trip data' });
        }

        return res
            .status(500)
            .json({ message: 'Unable to add trip' });
    }
};

// PUT: /trips/:tripCode - Updates an existing Trip
// Regardless of outcome, response must include HTTP status code
// and JSON message to the requesting client
const tripsUpdateTrip = async(req, res) => {
    try {
        const tripCode = req.params.tripCode.trim().toUpperCase();

        const q = await Model
            .findOneAndUpdate(
                { code: tripCode },
                {
                    code: req.body.code,
                    name: req.body.name,
                    length: req.body.length,
                    start: req.body.start,
                    resort: req.body.resort,
                    perPerson: req.body.perPerson,
                    image: req.body.image,
                    description: req.body.description
                },
                {
                    new: true,
                    runValidators: true
                }
            )
            .exec();

        if (!q) {
            return res
                .status(404)
                .json({ message: 'Trip not found' });
        }

        return res
            .status(200)
            .json(q);

    } catch (err) {
        console.error('Error updating trip:', err);

        if (err.name === 'ValidationError') {
            return res
                .status(400)
                .json({ message: 'Invalid trip data' });
        }

        return res
            .status(500)
            .json({ message: 'Unable to update trip' });
    }
};

module.exports = {
    tripsList,
    tripsFindByCode,
    tripsAddTrip,
    tripsUpdateTrip
};
const mongoose = require('mongoose');

// Define the trip schema
const tripSchema = new mongoose.Schema({
    code: {
        type: String,
        required: [true, 'Trip code is required'],
        trim: true,
        uppercase: true,
        minlength: [2, 'Trip code must be at least 2 characters'],
        maxlength: [20, 'Trip code cannot exceed 20 characters'],
        index: true
    },
    name: {
        type: String,
        required: [true, 'Trip name is required'],
        trim: true,
        minlength: [2, 'Trip name must be at least 2 characters'],
        maxlength: [100, 'Trip name cannot exceed 100 characters'],
        index: true
    },
    length: {
        type: String,
        required: [true, 'Trip length is required'],
        trim: true,
        maxlength: [50, 'Trip length cannot exceed 50 characters']
    },
    start: {
        type: Date,
        required: [true, 'Start date is required']
    },
    resort: {
        type: String,
        required: [true, 'Resort is required'],
        trim: true,
        minlength: [2, 'Resort must be at least 2 characters'],
        maxlength: [100, 'Resort cannot exceed 100 characters'],
        index: true
    },
    perPerson: {
        type: String,
        required: [true, 'Price per person is required'],
        trim: true
    },
    image: {
        type: String,
        required: [true, 'Image is required'],
        trim: true
    },
    description: {
        type: String,
        required: [true, 'Description is required'],
        trim: true,
        minlength: [10, 'Description must be at least 10 characters'],
        maxlength: [1000, 'Description cannot exceed 1000 characters']
    }
});

const Trip = mongoose.model('trips', tripSchema);
module.exports = Trip;
package com.example.andrewdepasqualeinventoryapp;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

// Handles adding new inventory items to database
public class AddItemActivity extends AppCompatActivity {

    // User interface components
    private EditText editItemName;
    private EditText editItemQuantity;
    private EditText editItemDescription;
    private Button buttonSaveItem;
    private Button buttonCancelItem;

    // Database object used to save inventory data
    private DatabaseHelper databaseHelper;

    // Runs when add item screen opened
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_item);

        // Connect Java variables to XML components
        editItemName = findViewById(R.id.editItemName);
        editItemQuantity = findViewById(R.id.editItemQuantity);
        editItemDescription = findViewById(R.id.editItemDescription);
        buttonSaveItem = findViewById(R.id.buttonSaveItem);
        buttonCancelItem = findViewById(R.id.buttonCancelItem);

        // Create database helper object
        databaseHelper = new DatabaseHelper(this);

        // Saves new item when Save Item button pressed
        buttonSaveItem.setOnClickListener(v -> {

            // Retrieve inventory info entered by user
            String itemName = editItemName.getText().toString().trim();
            String quantityText = editItemQuantity.getText().toString().trim();
            String description = editItemDescription.getText().toString().trim();

            // Prevent saving if item name or quantity empty
            if (itemName.isEmpty() || quantityText.isEmpty()) {
                Toast.makeText(this, "Please entire item name and quantity", Toast.LENGTH_SHORT).show();
                return;
            }

            // Convert quantity text to number
            int quantity = Integer.parseInt(quantityText);

            // Save item to inventory database
            boolean added = databaseHelper.addItem(itemName, quantity, description);

            // Return to inventory screen if item saved
            if (added) {
                Toast.makeText(this, "Item added", Toast.LENGTH_SHORT).show();
                finish();
            }

            // If item not saved
            else {
                Toast.makeText(this, "Item could not be added", Toast.LENGTH_SHORT).show();
            }
        });

        // Cancels add item process/returns to previous screen
        buttonCancelItem.setOnClickListener(v -> finish());
    }
}

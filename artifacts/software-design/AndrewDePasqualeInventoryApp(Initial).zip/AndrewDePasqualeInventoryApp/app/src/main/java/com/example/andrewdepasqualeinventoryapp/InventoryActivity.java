package com.example.andrewdepasqualeinventoryapp;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.Gravity;
import android.widget.Button;
import android.widget.GridLayout;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

// Displays inventory data also allows item updates/deletions
public class InventoryActivity extends AppCompatActivity {

    // User interface components
    private GridLayout gridInventory;
    private Button buttonAddItem;
    private Button buttonSmsSettings;

    // Database object used to access inventory data
    private DatabaseHelper databaseHelper;

    // Runs when inventory screen opened
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_inventory);

        // Connect Java variables to XML components
        gridInventory = findViewById(R.id.gridInventory);
        buttonAddItem = findViewById(R.id.buttonAddItem);
        buttonSmsSettings = findViewById(R.id.buttonSmsSettings);

        // Create database helper object
        databaseHelper = new DatabaseHelper(this);

        // Open add item screen when Add Item button pressed
        buttonAddItem.setOnClickListener(v -> {
            startActivity(new Intent(this, AddItemActivity.class));
        });

        // Open SMS permission screen when SMS Settings button pressed
        buttonSmsSettings.setOnClickListener(v -> {
            startActivity(new Intent(this, SmsPermissionActivity.class));
        });
    }

    // Reload inventory data whenever screen active
    @Override
    protected void onResume() {
        super.onResume();
        loadInventoryGrid();
    }

    // Builds inventory grid using database records
    private void loadInventoryGrid() {

        // Clear old grid data before loading updated rows
        gridInventory.removeAllViews();

        // Add header row
        addHeaderCell("Item");
        addHeaderCell("Qty");
        addHeaderCell("Status");
        addHeaderCell("Update");
        addHeaderCell("Delete");

        // Get all inventory items from database
        Cursor cursor = databaseHelper.getAllItems();

        // Display message if inventory empty
        if (cursor.getCount() == 0) {
            Toast.makeText(this, "No inventory items found", Toast.LENGTH_SHORT).show();
        }

        // Loop through all database rows
        while (cursor.moveToNext()) {

            // Retrieve item data from database
            int id = cursor.getInt(0);
            String itemName = cursor.getString(1);
            int quantity = cursor.getInt(2);

            // Determine stock status based on quantity
            String status;
            if (quantity == 0) {
                status = "Out";
            } else if (quantity <= 5) {
                status = "Low";
            } else {
                status = "In Stock";
            }

            // Add item info to grid
            addTextCell(itemName);
            addTextCell(String.valueOf(quantity));
            addTextCell(status);

            // Add quantity update buttons
            addUpdateButtons(id, quantity);

            // Add delete button
            addDeleteButton(id);
        }

        // Close database cursor
        cursor.close();
    }

    // Adds bold header text to grid
    private void addHeaderCell(String text) {
        TextView textView = new TextView(this);
        textView.setText(text);
        textView.setTypeface(null, android.graphics.Typeface.BOLD);
        textView.setPadding(8, 8, 8, 8);
        gridInventory.addView(textView);
    }

    // Adds regular item text to grid
    private void addTextCell(String text) {
        TextView textView = new TextView(this);
        textView.setText(text);
        textView.setPadding(8, 8, 8, 8);
        gridInventory.addView(textView);
    }

    // Adds plus/minus buttons for quantity updates
    private void addUpdateButtons(int id, int currentQuantity) {

        // Button setup
        LinearLayout buttonLayout = new LinearLayout(this);
        buttonLayout.setOrientation(LinearLayout.HORIZONTAL);
        buttonLayout.setGravity(Gravity.CENTER);

        // Minus button
        Button buttonMinus = new Button(this);
        buttonMinus.setText("-");

        // Plus button
        Button buttonPlus = new Button(this);
        buttonPlus.setText("+");

        // Decrease quantity when minus button pressed
        buttonMinus.setOnClickListener(v -> {
            int newQuantity = currentQuantity - 1;

            // Set lowest qauntity limit at 0
            if (newQuantity < 0) {
                newQuantity = 0;
            }

            databaseHelper.updateQuantity(id, newQuantity);
            loadInventoryGrid();
        });

        // Increase quantity when plus button pressed
        buttonPlus.setOnClickListener(v -> {
            int newQuantity = currentQuantity + 1;
            databaseHelper.updateQuantity(id, newQuantity);
            loadInventoryGrid();
        });

        buttonLayout.addView(buttonMinus);
        buttonLayout.addView(buttonPlus);
        gridInventory.addView(buttonLayout);
    }

    // Adds delete button for removing inventory items
    private void addDeleteButton(int id) {
        Button buttonDelete = new Button(this);
        buttonDelete.setText("Delete");

        // Delete selected item from database
        buttonDelete.setOnClickListener(v -> {
            boolean deleted = databaseHelper.deleteItem(id);

            // If item deleted
            if (deleted) {
                Toast.makeText(this, "Item deleted", Toast.LENGTH_SHORT). show();
                loadInventoryGrid();
            }

            // If delete failed
            else {
                Toast.makeText(this, "Delete failed", Toast.LENGTH_SHORT).show();
            }
        });

        gridInventory.addView(buttonDelete);
    }
}
package com.example.andrewdepasqualeinventoryapp;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.Gravity;
import android.widget.Button;
import android.widget.GridLayout;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.EditText;
import android.text.Editable;
import android.text.TextWatcher;

import androidx.appcompat.app.AppCompatActivity;

// Displays inventory data also allows item updates/deletions
public class InventoryActivity extends AppCompatActivity {

    // User interface components
    private GridLayout gridInventory;
    private Button buttonAddItem;
    private Button buttonSmsSettings;
    private EditText editSearch;

    // Database object used to access inventory data
    private DatabaseHelper databaseHelper;

    // Runs when inventory screen opened
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_inventory);

        // Connect Java variables to XML components
        gridInventory = findViewById(R.id.gridInventory);
        buttonAddItem = findViewById(R.id.buttonAddItem);
        buttonSmsSettings = findViewById(R.id.buttonSmsSettings);
        editSearch = findViewById(R.id.editSearch);

        // Create database helper object
        databaseHelper = new DatabaseHelper(this);

        // Filter inventory while user types in search field
        editSearch.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                loadInventoryGrid();
            }

            @Override
            public void afterTextChanged(Editable s) {
            }
        });

        // Open add item screen when Add Item button pressed
        buttonAddItem.setOnClickListener(v -> {
            startActivity(new Intent(this, AddItemActivity.class));
        });

        // Open SMS permission screen when SMS Settings button pressed
        buttonSmsSettings.setOnClickListener(v -> {
            startActivity(new Intent(this, SmsPermissionActivity.class));
        });
    }

    // Reload inventory data whenever screen active
    @Override
    protected void onResume() {
        super.onResume();
        loadInventoryGrid();
    }

    // Builds inventory grid using database records
    private void loadInventoryGrid() {

        // Clear old grid data before loading updated rows
        gridInventory.removeAllViews();

        // Add header row
        addHeaderCell("Item");
        addHeaderCell("Category");
        addHeaderCell("Qty");
        addHeaderCell("Status");
        addHeaderCell("Update");
        addHeaderCell("Delete");

        // Get search text entered by user
        String searchText = editSearch.getText().toString().trim();

        // Load all items when search is empty, otherwise load matching items
        Cursor cursor;
        if (searchText.isEmpty()) {
            cursor = databaseHelper.getAllItems();
        } else {
            cursor = databaseHelper.searchItems(searchText);
        }

        // Display message if no inventory records match
        if (cursor.getCount() == 0) {
            if (searchText.isEmpty()) {
                Toast.makeText(this, "No inventory items found", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "No matching inventory items found", Toast.LENGTH_SHORT).show();
            }
        }

        // Loop through all database rows
        while (cursor.moveToNext()) {

            // Retrieve item data from database
            int id = cursor.getInt(0);
            String itemName = cursor.getString(1);
            int quantity = cursor.getInt(2);
            String category = cursor.getString(4);
            int threshold = cursor.getInt(5);

            // Determine stock status based on quantity
            String status = getStockStatus(quantity, threshold);

            // Add item info to grid
            addTextCell(itemName);
            addTextCell(category);
            addTextCell(String.valueOf(quantity));
            addTextCell(status);

            // Add quantity update buttons
            addUpdateButtons(id, quantity);

            // Add delete button
            addDeleteButton(id);
        }

        // Close database cursor
        cursor.close();
    }

    // Determines stock status using item's quantity and threshold
    private String getStockStatus(int quantity, int threshold) {
        if (quantity == 0) {
            return "Out";
        } else if (quantity <= threshold) {
            return "Low";
        } else {
            return "In Stock";
        }
    }

    // Adds bold header text to grid
    private void addHeaderCell(String text) {
        TextView textView = new TextView(this);
        textView.setText(text);
        textView.setTypeface(null, android.graphics.Typeface.BOLD);
        textView.setPadding(8, 8, 8, 8);
        gridInventory.addView(textView);
    }

    // Adds regular item text to grid
    private void addTextCell(String text) {
        TextView textView = new TextView(this);
        textView.setText(text);
        textView.setPadding(8, 8, 8, 8);
        gridInventory.addView(textView);
    }

    // Adds plus/minus buttons for quantity updates
    private void addUpdateButtons(int id, int currentQuantity) {

        // Button setup
        LinearLayout buttonLayout = new LinearLayout(this);
        buttonLayout.setOrientation(LinearLayout.HORIZONTAL);
        buttonLayout.setGravity(Gravity.CENTER);

        // Minus button
        Button buttonMinus = new Button(this);
        buttonMinus.setText("-");

        // Plus button
        Button buttonPlus = new Button(this);
        buttonPlus.setText("+");

        // Decrease quantity when minus button pressed
        buttonMinus.setOnClickListener(v -> {
            int newQuantity = currentQuantity - 1;

            // Set lowest quantity limit at 0
            if (newQuantity < 0) {
                newQuantity = 0;
            }

            databaseHelper.updateQuantity(id, newQuantity);
            loadInventoryGrid();
        });

        // Increase quantity when plus button pressed
        buttonPlus.setOnClickListener(v -> {
            int newQuantity = currentQuantity + 1;
            databaseHelper.updateQuantity(id, newQuantity);
            loadInventoryGrid();
        });

        buttonLayout.addView(buttonMinus);
        buttonLayout.addView(buttonPlus);
        gridInventory.addView(buttonLayout);
    }

    // Adds delete button for removing inventory items
    private void addDeleteButton(int id) {
        Button buttonDelete = new Button(this);
        buttonDelete.setText("Delete");

        // Delete selected item from database
        buttonDelete.setOnClickListener(v -> {
            boolean deleted = databaseHelper.deleteItem(id);

            // If item deleted
            if (deleted) {
                Toast.makeText(this, "Item deleted", Toast.LENGTH_SHORT). show();
                loadInventoryGrid();
            }

            // If delete failed
            else {
                Toast.makeText(this, "Delete failed", Toast.LENGTH_SHORT).show();
            }
        });

        gridInventory.addView(buttonDelete);
    }
}
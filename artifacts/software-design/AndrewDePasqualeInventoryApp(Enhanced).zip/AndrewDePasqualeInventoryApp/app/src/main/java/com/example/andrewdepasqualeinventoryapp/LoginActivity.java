package com.example.andrewdepasqualeinventoryapp;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
// Handles user login/account creation
public class LoginActivity extends AppCompatActivity {

    // User interface components
    private EditText editUsername;
    private EditText editPassword;
    private Button buttonLogin;
    private Button buttonCreateAccount;

    // Database object to access user info
    private DatabaseHelper databaseHelper;

    // Runs when login screen first opened
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        // Connect Java variables to XML components
        editUsername = findViewById(R.id.editUsername);
        editPassword = findViewById(R.id.editPassword);
        buttonLogin = findViewById(R.id.buttonLogin);
        buttonCreateAccount = findViewById(R.id.buttonCreateAccount);

        // Create database helper object
        databaseHelper = new DatabaseHelper(this);

        // Checks user's login info when login button pressed
        buttonLogin.setOnClickListener(v -> {

            // Retrieve username/password entered by user
            String username = editUsername.getText().toString().trim();
            String password = editPassword.getText().toString().trim();

            // Prevent login if either field empty
            if (username.isEmpty() || password.isEmpty()) {
                Toast.makeText(this, "Please enter username and password", Toast.LENGTH_SHORT).show();
                return;
            }

            // Verify username/password exist in database
            boolean validUser = databaseHelper.checkUser(username, password);

            // Allow user to continue if login valid
            if (validUser) {
                Toast.makeText(this, "Login successful", Toast.LENGTH_SHORT).show();

                // Opens inventory screen
                startActivity(new Intent(this, InventoryActivity.class));
            }

            // Display error if login info not correct
            else {
                Toast.makeText(this, "Invalid login", Toast.LENGTH_SHORT).show();
            }
        });

        // Creates new account when Create New Login button pressed
        buttonCreateAccount.setOnClickListener(v -> {

            // Retrieve username/password entered by user
            String username = editUsername.getText().toString().trim();
            String password = editPassword.getText().toString().trim();

            // Prevent account creation if either field empty
            if (username.isEmpty() || password.isEmpty()) {
                Toast.makeText(this, "Please enter username and password", Toast.LENGTH_SHORT).show();
                return;
            }

            // Attempt to save new account in database
            boolean created = databaseHelper.addUser(username, password);

            // Allow user to continue if login valid
            if (created) {
                Toast.makeText(this, "Account created", Toast.LENGTH_SHORT).show();
            }

            // Inform user if username already exists
            else {
                Toast.makeText(this, "Username already exists", Toast.LENGTH_SHORT).show();
            }
        });
    }
}
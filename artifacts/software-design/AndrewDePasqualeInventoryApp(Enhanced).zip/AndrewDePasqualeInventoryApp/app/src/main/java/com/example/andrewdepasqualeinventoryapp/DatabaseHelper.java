package com.example.andrewdepasqualeinventoryapp;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

// Handles database creation and inventory/user table operations
public class DatabaseHelper extends SQLiteOpenHelper {

    // Database name/version
    public static final String DATABASE_NAME = "InventoryApp.db";
    private static final int DATABASE_VERSION = 2;

    // Names of database tables
    public static final String USER_TABLE = "users";
    public static final String INVENTORY_TABLE = "inventory";

    // Constructor used to create/open database
    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    // Creates database tables first time app runs
    @Override
    public void onCreate(SQLiteDatabase db) {

        // Creates table to store usernames/passwords
        db.execSQL("CREATE TABLE " + USER_TABLE + " (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "username TEXT UNIQUE, " + "password TEXT)");

        // Creates table to store inventory items
        db.execSQL("CREATE TABLE " + INVENTORY_TABLE + " (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "itemName TEXT NOT NULL, " +
                "quantity INTEGER NOT NULL CHECK(quantity >= 0), " +
                "description TEXT, " +
                "category TEXT NOT NULL, " +
                "threshold INTEGER NOT NULL CHECK(threshold >= 0))");
    }

    // Recreates the database if version number changes
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

        // Upgrade version 1 inventory data without deleting existing records
        if (oldVersion < 2) {
            db.execSQL("ALTER TABLE " + INVENTORY_TABLE + " ADD COLUMN category TEXT NOT NULL DEFAULT 'General'");

            db.execSQL("ALTER TABLE " + INVENTORY_TABLE + " ADD COLUMN threshold INTEGER NOT NULL DEFAULT 5");
        }
    }

    // Adds new user account to database
    public boolean addUser(String username, String password) {
        SQLiteDatabase db = this.getWritableDatabase();

        // Stores username/password
        ContentValues values = new ContentValues();
        values.put("username", username);
        values.put("password", password);

        // Returns true if the account was created successfully
        long result = db.insert(USER_TABLE, null, values);
        return result != -1;
    }

    // Verifies user's login credentials
    public boolean checkUser(String username, String password) {
        SQLiteDatabase db = this.getReadableDatabase();

        // Searches for matching username/password
        Cursor cursor = db.rawQuery("SELECT * FROM " + USER_TABLE +
                " WHERE username=? AND password=?", new String[]{username, password}
        );

        // Determines whether matching account exists
        boolean exists = cursor.getCount() > 0;

        // Closes query results
        cursor.close();

        return exists;
    }

    // Adds a new inventory item
    public boolean addItem(String itemName, int quantity, String description, String category, int threshold) {
        SQLiteDatabase db = this.getWritableDatabase();

        // Prevent invalid inventory values from reaching database
        if (itemName == null || itemName.trim().isEmpty()
                || category == null || category.trim().isEmpty()
                || quantity < 0 || threshold < 0) {
            return false;
        }

        // Stores inventory information
        ContentValues values = new ContentValues();
        values.put("itemName", itemName.trim());
        values.put("quantity", quantity);
        values.put("description", description);
        values.put("category", category.trim());
        values.put("threshold", threshold);

        // Inserts item into inventory table
        long result = db.insert(INVENTORY_TABLE, null, values);

        return result != -1;
    }

    // Retrieves all inventory records
    public Cursor getAllItems() {
        SQLiteDatabase db = this.getReadableDatabase();

        // Returns every item stored in inventory table
        return db.rawQuery(
                "SELECT * FROM " + INVENTORY_TABLE + " ORDER BY itemName ASC",
                null
        );
    }

    // Searches inventory records by item name or category
    public Cursor searchItems(String searchText) {
        SQLiteDatabase db = this.getReadableDatabase();

        String searchPattern = "%" + searchText.trim() + "%";

        return db.rawQuery(
                "SELECT * FROM " + INVENTORY_TABLE +
                        " WHERE itemName LIKE ? OR category LIKE ?" +
                        " ORDER BY itemName ASC",
                new String[]{searchPattern, searchPattern}
        );
    }

    // Updates quantity of existing inventory item
    public boolean updateQuantity(int id, int quantity) {
        SQLiteDatabase db = this.getWritableDatabase();

        // Stores updated quantity
        ContentValues values = new ContentValues();
        values.put("quantity", quantity);

        // Updates matching inventory record
        int result = db.update(INVENTORY_TABLE, values, "id=?",
                new String[]{String.valueOf(id)});

        return result > 0;
    }

    // Deletes inventory item from database
    public boolean deleteItem(int id) {
        SQLiteDatabase db = this.getWritableDatabase();

        // Removes selected inventory item
        int result = db.delete(INVENTORY_TABLE, "id=?",
                new String[]{String.valueOf(id)});

        return result > 0;
    }
}

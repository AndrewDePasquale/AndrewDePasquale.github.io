package com.example.andrewdepasqualeinventoryapp;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

// Handles adding new inventory items to database
public class AddItemActivity extends AppCompatActivity {

    // User interface components
    private EditText editItemName;
    private EditText editItemQuantity;
    private EditText editItemDescription;
    private EditText editCategory;
    private EditText editThreshold;
    private Button buttonSaveItem;
    private Button buttonCancelItem;

    // Database object used to save inventory data
    private DatabaseHelper databaseHelper;

    // Runs when add item screen opened
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_item);

        // Connect Java variables to XML components
        editItemName = findViewById(R.id.editItemName);
        editItemQuantity = findViewById(R.id.editItemQuantity);
        editItemDescription = findViewById(R.id.editItemDescription);
        editCategory = findViewById(R.id.editCategory);
        editThreshold = findViewById(R.id.editThreshold);
        buttonSaveItem = findViewById(R.id.buttonSaveItem);
        buttonCancelItem = findViewById(R.id.buttonCancelItem);

        // Create database helper object
        databaseHelper = new DatabaseHelper(this);

        // Saves new item when Save Item button pressed
        buttonSaveItem.setOnClickListener(v -> {

            // Retrieve inventory info entered by user
            String itemName = editItemName.getText().toString().trim();
            String quantityText = editItemQuantity.getText().toString().trim();
            String description = editItemDescription.getText().toString().trim();
            String category = editCategory.getText().toString().trim();
            String thresholdText = editThreshold.getText().toString().trim();

            // Prevent saving if item name or quantity empty
            if (itemName.isEmpty() || quantityText.isEmpty()
                    || category.isEmpty() || thresholdText.isEmpty()) {

                Toast.makeText(
                        AddItemActivity.this,
                        "Please enter item name, quantity, category, and threshold",
                        Toast.LENGTH_SHORT
                ).show();

                return;
            }

            // Convert quantity text to number
            int quantity;
            int threshold;

            try {
                quantity = Integer.parseInt(quantityText);
                threshold = Integer.parseInt(thresholdText);
            } catch (NumberFormatException e) {
                Toast.makeText(
                        AddItemActivity.this,
                        "Quantity and threshold must be valid numbers",
                        Toast.LENGTH_SHORT
                ).show();

                return;
            }

            if (quantity < 0 || threshold < 0) {
                Toast.makeText(
                        AddItemActivity.this,
                        "Quantity and threshold cannot be negative",
                        Toast.LENGTH_SHORT
                ).show();

                return;
            }

            // Save item to inventory database
            boolean added = databaseHelper.addItem(itemName, quantity, description, category, threshold);

            // Return to inventory screen if item saved
            if (added) {
                Toast.makeText(this, "Item added", Toast.LENGTH_SHORT).show();
                finish();
            }

            // If item not saved
            else {
                Toast.makeText(this, "Item could not be added", Toast.LENGTH_SHORT).show();
            }
        });

        // Cancels add item process/returns to previous screen
        buttonCancelItem.setOnClickListener(v -> finish());
    }
}

package com.example.andrewdepasqualeinventoryapp;

import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

// Handles SMS permission requests/test inventory alert messages
public class SmsPermissionActivity extends AppCompatActivity {

    // Request code used when asking user for SMS permission
    private static final int SMS_PERMISSION_CODE = 100;

    // User interface components
    private Button buttonAllowSms;
    private Button buttonDenySms;
    private TextView textSmsStatus;

    // Runs when SMS permission screen is opened
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sms_permission);

        // Connect Java variables to XML components
        buttonAllowSms = findViewById(R.id.buttonAllowSms);
        buttonDenySms = findViewById(R.id.buttonDenySms);
        textSmsStatus = findViewById(R.id.textSmsStatus);

        // Requests SMS permission when Allow SMS button pressed
        buttonAllowSms.setOnClickListener(v -> requestSmsPermission());

        // Lets app continue without SMS alerts
        buttonDenySms.setOnClickListener(v -> {
            textSmsStatus.setText("SMS alerts are disabled. App will still work without text notifications.");
            Toast.makeText(this, "SMS alerts disabled", Toast.LENGTH_SHORT).show();
            finish();
        });
    }

    // Checks whether SMS permission has already been granted
    private void requestSmsPermission() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
                == PackageManager.PERMISSION_GRANTED) {
            sendLowInventoryAlert();
        } else {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.SEND_SMS},
                    SMS_PERMISSION_CODE);
        }
    }

    // Handles user's permission response
    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        if (requestCode == SMS_PERMISSION_CODE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                textSmsStatus.setText("SMS permission granted. Low inventory alerts are enabled");
                sendLowInventoryAlert();
                finish();
            } else {
                textSmsStatus.setText("SMS permission denied. The app will continue without SMS alerts");
                Toast.makeText(this, "SMS permission denied", Toast.LENGTH_SHORT).show();
                finish();
            }
        }
    }

    // Sends sample low inventory SMS alert
    private void sendLowInventoryAlert() {
        try {
            SmsManager smsManager = SmsManager.getDefault();

            // Emulator friendly placeholder number
            String phoneNumber = "5555";
            String message = "Inventory Alert: An item has reached zero quantity.";

            smsManager.sendTextMessage(phoneNumber, null, message, null, null);

            textSmsStatus.setText("SMS alert sent for low inventory.");
            Toast.makeText(this, "SMS alert sent", Toast.LENGTH_SHORT).show();
            finish();
        }

        catch (Exception e) {
            textSmsStatus.setText("SMS permission is enabled, but the alert could not be sent.");
            Toast.makeText(this, "SMS could not be sent", Toast.LENGTH_SHORT).show();
            finish();
        }
    }
}

